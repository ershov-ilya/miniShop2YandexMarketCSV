<?php
/**
 * The home manager controller for miniShop2YandexMarketCSV.
 *
 */
class miniShop2YandexMarketCSVHomeManagerController extends miniShop2YandexMarketCSVMainController {
	/* @var miniShop2YandexMarketCSV $miniShop2YandexMarketCSV */
	public $miniShop2YandexMarketCSV;


	/**
	 * @param array $scriptProperties
	 */
	public function process(array $scriptProperties = array()) {
	}


	/**
	 * @return null|string
	 */
	public function getPageTitle() {
		return $this->modx->lexicon('minishop2yandexmarketcsv');
	}


	/**
	 * @return void
	 */
	public function loadCustomCssJs() {
		$this->addJavascript($this->miniShop2YandexMarketCSV->config['jsUrl'] . 'mgr/widgets/items.grid.js');
		$this->addJavascript($this->miniShop2YandexMarketCSV->config['jsUrl'] . 'mgr/widgets/home.panel.js');
		$this->addJavascript($this->miniShop2YandexMarketCSV->config['jsUrl'] . 'mgr/sections/home.js');
		$this->addHtml('<script type="text/javascript">
		Ext.onReady(function() {
			MODx.load({ xtype: "minishop2yandexmarketcsv-page-home"});
		});
		</script>');
	}


	/**
	 * @return string
	 */
	public function getTemplateFile() {
		return $this->miniShop2YandexMarketCSV->config['templatesPath'] . 'home.tpl';
	}
}