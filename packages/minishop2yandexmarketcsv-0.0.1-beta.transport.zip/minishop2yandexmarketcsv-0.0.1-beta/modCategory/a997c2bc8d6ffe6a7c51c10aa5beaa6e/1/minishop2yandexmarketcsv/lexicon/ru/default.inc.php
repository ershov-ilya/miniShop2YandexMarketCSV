<?php

include_once 'setting.inc.php';

$_lang['minishop2yandexmarketcsv'] = 'miniShop2YandexMarketCSV';
$_lang['minishop2yandexmarketcsv_menu_desc'] = 'Пример расширения для разработки.';
$_lang['minishop2yandexmarketcsv_items'] = 'Предметы';
$_lang['minishop2yandexmarketcsv_item_create'] = 'Создать предмет';
$_lang['minishop2yandexmarketcsv_item_err_ae'] = 'Предмет с таким именем уже существует.';
$_lang['minishop2yandexmarketcsv_item_err_nf'] = 'Предмет не найден.';
$_lang['minishop2yandexmarketcsv_item_err_ns'] = 'Предмет не указан.';
$_lang['minishop2yandexmarketcsv_item_err_remove'] = 'Ошибка при удалении Предмета.';
$_lang['minishop2yandexmarketcsv_item_err_save'] = 'Ошибка при сохранении Предмета.';
$_lang['minishop2yandexmarketcsv_item_remove'] = 'Удалить Предмет';
$_lang['minishop2yandexmarketcsv_items_remove'] = 'Удалить Предметы';
$_lang['minishop2yandexmarketcsv_items_remove_confirm'] = 'Вы уверены, что хотите удалить эти Предметы?';
$_lang['minishop2yandexmarketcsv_item_remove_confirm'] = 'Вы уверены, что хотите удалить этот Предмет?';
$_lang['minishop2yandexmarketcsv_item_update'] = 'Изменить Предмет';
$_lang['minishop2yandexmarketcsv_intro_msg'] = 'Управляйте вашими предметами.';