<?php

$_lang['area_minishop2yandexmarketcsv_main'] = 'Основные';

$_lang['setting_minishop2yandexmarketcsv_some_setting'] = 'Какая-то настройка';
$_lang['setting_minishop2yandexmarketcsv_some_setting_desc'] = 'Это описание для какой-то настройки';