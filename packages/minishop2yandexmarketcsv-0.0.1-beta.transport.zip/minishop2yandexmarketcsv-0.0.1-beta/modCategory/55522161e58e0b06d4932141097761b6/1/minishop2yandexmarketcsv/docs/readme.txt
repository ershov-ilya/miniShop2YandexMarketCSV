--------------------
miniShop2YandexMarketCSV
--------------------
Author: Ilya Ershov, skype: ershov.ilya
--------------------

http://github.com/ershov-ilya/miniShop2YandexMarketCSV/