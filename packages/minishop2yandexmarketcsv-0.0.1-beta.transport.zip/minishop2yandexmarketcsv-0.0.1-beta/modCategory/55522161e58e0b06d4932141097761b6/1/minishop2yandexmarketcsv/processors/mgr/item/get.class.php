<?php
/**
 * Get an Item
 */
class miniShop2YandexMarketCSVItemGetProcessor extends modObjectGetProcessor {
	public $objectType = 'miniShop2YandexMarketCSVItem';
	public $classKey = 'miniShop2YandexMarketCSVItem';
	public $languageTopics = array('minishop2yandexmarketcsv:default');
}

return 'miniShop2YandexMarketCSVItemGetProcessor';