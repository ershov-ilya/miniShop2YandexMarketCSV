<?php
/**
 * @package minishop2yandexmarketcsv
 */
class miniShop2YandexMarketCSVItem extends xPDOSimpleObject {}