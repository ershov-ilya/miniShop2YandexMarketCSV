<?php
require_once (dirname(dirname(__FILE__)) . '/minishop2yandexmarketcsvitem.class.php');
class miniShop2YandexMarketCSVItem_mysql extends miniShop2YandexMarketCSVItem {}